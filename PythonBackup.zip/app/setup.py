import os

if not os.path.isdir('snapshots'):
    os.mkdir('snapshots')